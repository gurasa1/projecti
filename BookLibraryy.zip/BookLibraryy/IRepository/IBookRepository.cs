﻿using BookLibraryy.Models;

namespace BookLibraryy.IRepository
{
    public interface IBookRepository  : IGenericRepository<Book>
    {
     
    }
}
