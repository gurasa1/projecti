﻿using BookLibraryy.Models;

namespace BookLibraryy.IRepository
{
    public interface IGenreRepository : IGenericRepository<Genre>
    {
      
    }
}
